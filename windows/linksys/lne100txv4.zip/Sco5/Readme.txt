****************************************************************************
                 Linksys LNE100TX Fast Ethernet Adapter(LNE100TX v4)

			 SCO Unix Driver Installation
			 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                 Copyright (C) 2000 Linksys Inc.
			     All rights reserved.
****************************************************************************

Installation Procedure
----------------------

1. Prepare a formatted diskette on any DOS machine.  For example, type:

     C>format a:

   Note: Make sure your diskette is free from bad sectors.
	 Verify this using the DOS SCANDISK or CHKDSK command.

2. Now login to UNIX system as supervisor (root) and enter the Maintenance 
   mode.

   Note: Make sure that the current directory is "/" using UNIX command --
	 pwd.

   Please follow the following steps to uncompress the package file:

   > cd /tmp		(and inserts the package floppy in the proper 
                        drive, i.e. a:)
   > doscp a:/sco5/lne100tx.sc5 ./pcidriver
			(then replaces with the prepared formatted diskette
			done in step 1)
   > dd if=./pcidriver of=/dev/rfd0135ds18
			(Note: Use another device file name if you use 
			different floppy drive)

   Now the package installation diskette is ready for installing.

3. The following sections describe the configuration of the driver. It is 
   suggested that you should perform these instructions in the singler-user
   environment.

   Run "custom" utility and select the "Install new package" option. It will
   prompt you to insert driver diskette and then choose the "FULL" option to
   install this package.

   After running the custom utility and the new package is installed, you 
   should use the "netconfig" command to add the driver into your system 
   like the step 4 below.

4. Run "netconfig". Add the desired chain. The driver will be called as "lne100tx".

5. When the chain has been configured, select 'q' from the netconfig menu. 
   and relink the kernel at the prompt.
