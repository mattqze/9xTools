*****************************************************************************
             Linksys LNE100TX Fast Ethernet Adapter(LNE100TX v4)
			    
		      NetWare ODI Server Driver For 3.12
		      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
									    
	                Copyright (C) 2000 Linksys Inc.	    
			     All rights reserved.			    
*****************************************************************************

Installation Procedure
======================

 Loading Driver Manually:
 ------------------------
  1. On the server console, load the driver directly, for example:

	LOAD A:\Netware\Server\NW31X\NBI31X.NLM
	LOAD A:\Netware\Server\NW31X\MSM31X.NLM
	LOAD A:\Netware\Server\NW31X\ETHERTSM.NLM
	LOAD A:\Netware\Server\NW31X\LNE100TX FRAME=Ethernet_802.2

  2. Bind with IPX:

	BIND IPX LNE100TX

  3. You can login the server from a workstation, and then copy LNE100TX.LAN,
     NBI31X.NLM, MSM31X.NLM and ETHERTSM.NLM to the directory SYS:\SYSTEM
     on server. Add the LOAD and BIND command lines to AUTOEXEC.NCF file
     so that the lan driver will be loaded automatically while the server
     starting up next time.

  ** NOTE **
     Multiple LAN Adapters in a system:
      If you want to install mutiple LAN adapters in a server, you have to 
      use the keyword, SLOT, to let driver locate the right adapter.
      For example:

        LOAD LNE100TX SLOT=1 FRAME=Ethernet_802.2 NAME=Lan_1
        BIND IPX TO Lan_1 NET=2001
        LOAD LNE100TX SLOT=2 FRAME=Ethernet_802.2 NAME=Lan_2
        BIND IPX TO Lan_2 NET=2002


Configuration Parameters
========================

 Custom Keywords
 ---------------
  There are five parameters provided for specifying adapter's speed and 
  duplex mode : AUTO, 10-HD, 10-FD, 100-HD and 100-FD.

    For example:
        LOAD LNE100TX 100-HD FRAME=Ethernet_802.2 NAME=LAN_A
        BIND IPX TO LAN_A NET=11



All trademarks or brand names mentioned are properties of their respective 
companies.
