*****************************************************************************
              Linksys LNE100TX Fast Ethernet Adapter (LNE100TX v4)

                 NetWare ODI Client Driver For DOS Workstation
                 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                  Copyright (C) 2000 Linksys.
                             All rights reserved.
*****************************************************************************

This section describes the procedure to install the NetWare DOS ODI
workstation driver for your adapter.


Installation Procedure
======================
Before you start with the installation process, make sure that the adapter
is properly installed and configured. Make sure that your NetWare operating
system is properly installed.

If there are NetWare client programs such as: LSL.COM, IPXODI, and VLM.EXE
in your system already, you can use the following procedures to setup your
system.

  1. Copy the A:\NETWARE\Client\DOS\LNE100TX.COM file to the NetWare client
     directory which contains NET.CFG, LSL.COM, IPXODI.COM, and VLM.EXE
     with related *.VLM files.

  2. Update the NET.CFG file. You can refer to the NET.CFG sample.

  3. Make sure to add LASTDRIVE=Z in your CONFIG.SYS file.

  4. Enter the following commands to connect to your Novell server:
                LSL
                LNE100TX
                IPXODI
                VLM
                F:
                LOGIN <user_name>


  ** NOTE **
     Multiple LAN Adapters in a system:
      If you want to install multiple LAN adapter in your system, you have
      to use "SLOT" keyword in NET.CFG to select which adapter to use with
      your netware client.



Configuration Files
===================
  File Name:            NET.CFG

  Sample of configuration file:
-----------------------------------------------------------------------------
Link Driver LNE100TX
    FRAME Ethernet_802.2
    FRAME Ethernet_802.3
    FRAME Ethernet_SNAP
    FRAME Ethernet_II

;       No_Early_Rx_Interrupt_Enable    ; Certification, please remove the
                                        ; first ";" of this line
;       FORCE_MEDIA
;       Connection_Type = 10MFD ; 10M 10MFD 100M 100MFD, default is AUTO
        TX_THRESHOLD    = 0     ; 0..3, 4=Store and forward, default=0
        RX_THRESHOLD    = 1     ; 0..2, 2=Store and forward, default=1
        CAL             = 2     ; 0..3, default = 2
        PBL             = 10    ; 0,1,2,4,8,10,20, default = 10
        Rx_Buffer_Size  = 100   ; Hex number, 100-600
;       Slot  1
        RX_FIFO_SIZE    = 2     ; 0..2, 0 ~ 2:2K, 3:1K; 0 is default

NetWare DOS Requester
        FIRST NETWORK DRIVE = F
        NETWARE PROTOCOL = NDS BIND
;       MAX IPG = 0
;       PBURST READ WINDOW SIZE=45
;       PBURST WRITE WINDOW SIZE=45

-----------------------------------------------------------------------------
All trademarks and brand names mentioned belong to their respective owners.

** Note **
  Its PCI cycle maybe slower on some machines. At this time, you should enable
  store and forward function in NET.CFG.

