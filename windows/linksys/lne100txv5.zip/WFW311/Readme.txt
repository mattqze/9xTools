*****************************************************************************
                 Linksys LNE100TX(v5) Fast Ethernet Adapter

           NDIS 2 Driver For Windows for WorkGroup 3.11 Installation
           ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                    Copyright (C) 1999-2001 LinkSys Group Inc.
                             All rights reserved.
*****************************************************************************

Installation Procedure
======================

  1. Start the Windows for Workgroup 3.11.

  2. Click the "Network" icon in the Program Manager Window.

  3. Click the "Network Setup" icon in the Network Window.

  4. Click the "Network" button in the "Network Setup" dialog box.

  5. Select the "Install Microsoft Windows Network" item and click "OK" button
     in the "Networks" dialog box.

  6. When the "Network Setup" dialog box appears, select "Drivers..." button.

  7. Select "Add Adapters..." from the "Network Drivers" dialog box.

  8. Select "Unlisted or Updated Network Adapter".

  9. When the "Install Driver" window appears, insert the driver disk into
     drive A:, type "A:\WFW311" and press <Enter>.

 10. Press <Enter> to select "Linksys LNE100TX(v5) Fast Ethernet Adapter".

 11. Click "Setup..." if you want to modify the advanced features.

 12. Click "Close" in the "Network Drivers" dialog box if you configure
     completed the advanced features or skip last step.

 13. Click "OK" in the "Network Setup" dialog box.

 14. Configure all Kinds of name (User, Workgourp, Computer) in the "Microsoft
     Windows Network Name" dialog box, then click "OK" button.

 15. Close the "Install Driver" windows and restart the computer.


Sample Configuration Files
==========================

  1. CONFIG.SYS File

        FILES=30
        buffers=30
        STACKS=9,256
        DEVICE=c:\windows\HIMEM.sys
        DEVICE=C:\WINDOWS\IFSHLP.SYS
        LASTDRIVE=y

  2. PROTOCOL.INI File on Windows for Workgroups

        [network.setup]
          version=0x3100
          netcard=LNE100,1,LNE100
          transport=ms$netbeui,MS$NETBEUI
          lana0=LNE100,1,ms$netbeui

        [protman]
          DriverName=PROTMAN$
          PRIORITY=MS$NETBEUI

        [LNE100]
          DriverName=LNE100$
          SIA_MODE = AUTODETECT

        [MS$NETBEUI]
          DriverName=netbeui$
          SESSIONS=10
          NCBS=32
          BINDINGS=LNE100
          LANABASE=0

  3. AUTOEXEC.BAT File

        C:\WINDOWS\net start
        C:\WINDOWS\SMARTDRV.EXE
        @ECHO OFF
        PROMPT $p$g
        PATH C:\WINDOWS;
        SET TEMP=C:\WINDOWS\TEMP




All trademarks or brand names mentioned are properties of their respective
companies.
