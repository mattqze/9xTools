*****************************************************************************
                   Linksys LNE100TX(v5) Fast Ethernet Adapter

                          Packet Driver Installation
                          ~~~~~~~~~~~~~~~~~~~~~~~~~~

                          Copyright (C) 1999-2001 LinkSys Group Inc.
                             All rights reserved.
*****************************************************************************

I. The driver LNE100TX.COM can be used for the following:
   Linksys LNE100TX(v5) Fast Ethernet Adapter


LNE100TX          syntax:

LNE100TX          [-#] [-a] [-t] [-f] [-s] [-n] [-w] [-u] [-h] <PD_INT_NO>


Parameter       Explain
-----------------------------------------------------------------------------
[-#]            The "-#" option will let the driver work on a specific adapter
                when multiple Linksys LNE100TX(v5) Fast Ethernet Adapter
                are found in the computer system.  For example, "-1" means
                the first adapter will be activated by the driver, "-2" means
                the second adapter will be activated, ... etc.

                Maximums of 4 adapters are supported simultaneously.

[-a]            The "-a" option will let driver perform automatic media
                detection during driver initialization.  The detection
                sequence is

                TP 100Mbps Full Duplex ---> TP 10Mbps Full Duplex --->
                TP 100Mbps Half Duplex ---> TP 10Mbps Half Duplex

                If no physical media is attached to the adapter then TP
                100Mbps Full Duplex is the default media.

[-t]            The "-t" option is to use Twisted Pair (RJ-45) (10BASE-T) as
                the transmission media. And it is also the default setting.

[-f]            The "-f" option enables FULL_DUPLEX feature of the adapters.
                It has no effect except when Twisted Pair is used.

[-s]            The "-s" option sets the adapter line speed to 100Mbps. It is
                a dedicated option for the Fast Ethernet adapter.

[-n]            Your NOVELL server uses NOVELL ISO-like packets. Your NOVELL
                workstation uses NOVELL 8137 packets. You can use this option
                to convert NOVELL 8137 packets into NOVELL ISO-like packets.

[-w]            Steve Wallace added a hack to let the packet drivers run under
                Windows. This is not to be construed with the proper solution,
                which is to write a TCP/IP package for Windows.

                This hack is enabled only when you use the '-w' switch.

[-u]            This option unloads the Packet Driver.

[-h]            This option displays the on-line help.

<PD_INT_NO>     This specifies the software interrupt (INT) where you'll load
                the packet driver. It must be in the range 0x60 to 0x80.

-----------------------------------------------------------------------------
Notice!!  The PC/TCP kernel, by default, is loaded at interrupt 0x61
          (so don't load the packet driver there!)



Example:

The following command line loads the
Linksys LNE100TX(v5) Fast Ethernet Adapter
Packet Driver at software interrupt 60h, transmission media is
automatically-detected:

                LNE100TX -a 0x60  or LNE100TX 0x60

** Note **
   The default transmission media is automatic-detection.
   The prefix of 0x to the parameters.


II. After the Packet Driver is loaded, you can run the PC/TCP kernel
   ETHDRV.EXE. the PC is then ready for PC/TCP communications.
   To run PC/TCP applications, You need to load PC/TCP Kernel ("ETHDRV.EXE").

   a. Refer to PC/TCP manual, Command Reference section, Chapter 2.3.

   b. The following example loads the PC/TCP Kernel and allocates 8 packet
      buffers. Increasing the number of packet buffers (from the default of
      5) prevents dropping of packets due to buffer shortage.

                ETHDRV -p 8 <Enter>

   c. At this point, you are ready to run PC/TCP applications
      (e.g., 'ftp', 'telnet').
      example ftp 192.72.24.202 , 192.72.24.202  is host address.
      With regard to host address, you must know its address.

   For information regarding the "FTP's PC/TCP Network Software for DOS"
   packages, please contact:

                FTP Software, Inc.
                26 Princess Street
                Wakefield, MA  01880
                (617) 246-0900


III. How to Communicate with NCSA TelNet.

   1. Make sure you have the correct version of NCSA Telnet for the PC.
      You need version 2.3 or later to support the packet driver interface.

   2. Install the NCSA software onto your system. Please refer to the NCSA
      documentation for detailed instructions.

   3. Load Packet Driver (LNE100TX 0x60):

      a. Refer to "Packet Driver Syntax" section above.
      b. To view the hint screen, type

                LNE100TX -h <Enter>

      c. The following example will load the packet driver using interrupt
         vector 60 (hex). The IO_BASE and IRQ will be read from adapter
         configuration space:

                LNE100TX 0x60   <Enter>

   4. At this point you are ready to run NCSA applications
      (e.g., 'ftp', 'telnet', etc.)

      for example :
                ftp 203.70.238.105, while 203.70.238.105 is the host address.


   For information regarding NCSA's products please contact:

                National Center for Supercomputing Applications
                264 Computing Applications Building
                605 E. Springfield Ave.
                Champaign, Ill. 61820
                (217) 244-0638
                telbug@ncsa.uiuc.edu


